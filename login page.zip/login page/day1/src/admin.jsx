import React from 'react';

function Admin() {
    return (
        <div>
           <h2>Welcome to Cric World</h2>
        </div>
    );
}

export default Admin;